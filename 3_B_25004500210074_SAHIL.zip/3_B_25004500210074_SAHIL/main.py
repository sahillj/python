"""
PTMAE: Pure Python Transactional Micro-Banking & Audit Engine
Course project: Python Programming Units 1-5

Only the permitted modules (random and datetime) may be imported.
This implementation uses built-in Python features for all other tasks.
"""

from datetime import datetime


# ============================================================
# MODULE 1 — State Control Engine and Trajectory Guards
# ============================================================

def compound_interest(principal, rate_percent, periods):
    """Calculate compound interest using arithmetic operators only."""
    amount = principal
    period = 0
    # Repeated multiplication avoids importing the math module.
    while period < periods:
        amount = amount * (1 + rate_percent / 100)
        period += 1
    return amount - principal


def calculate_penalty(amount, penalty_rate_percent):
    """Calculate a penalty fee using basic arithmetic."""
    return amount * penalty_rate_percent / 100


def trajectory_guard(initial_balance, transactions, safety_threshold=0, terminate=False):
    """Process transactions and stop when balance is unsafe or termination is requested."""
    balance = initial_balance
    processed = []
    for transaction in transactions:
        # Short-circuit evaluation stops processing on either guard condition.
        if balance < safety_threshold or terminate:
            break
        balance += transaction
        processed.append(transaction)
    return balance, processed


def command_loop():
    """Run a nested-loop command interface until the user enters exit."""
    print("\nPTMAE command interface")
    print("Commands: interest, penalty, balance, exit")
    balance = 5000.0
    while True:
        command = input("PTMAE> ").strip().lower()
        while command == "":
            print("Please enter a command.")
            command = input("PTMAE> ").strip().lower()

        if command == "exit":
            print("Exiting PTMAE.")
            break
        elif command == "balance":
            print("Current balance: {:.2f}".format(balance))
        elif command == "interest":
            try:
                principal = float(input("Principal: "))
                rate = float(input("Annual rate (%): "))
                periods = int(input("Number of periods: "))
                if principal < 0 or rate < 0 or periods < 0:
                    raise ValueError("Values must be non-negative.")
                interest = compound_interest(principal, rate, periods)
                balance += interest
                print("Compound interest: {:.2f}".format(interest))
            except ValueError as error:
                print("Invalid interest input:", error)
        elif command == "penalty":
            try:
                amount = float(input("Transaction amount: "))
                rate = float(input("Penalty rate (%): "))
                if amount < 0 or rate < 0:
                    raise ValueError("Values must be non-negative.")
                fee = calculate_penalty(amount, rate)
                balance -= fee
                print("Penalty fee: {:.2f}".format(fee))
            except ValueError as error:
                print("Invalid penalty input:", error)
        else:
            print("Unknown command. Use interest, penalty, balance, or exit.")


# ============================================================
# MODULE 2 — Native Log Parser and Closure Mechanics
# ============================================================

def parse_raw_log_line(line, delimiter=",", quote_char='"'):
    """Parse one delimited line manually, supporting quotes and escaped quotes."""
    tokens = []
    current = ""
    in_quotes = False
    index = 0

    while index < len(line):
        character = line[index]

        if character == quote_char:
            if in_quotes:
                # Two quote characters inside a quoted field mean one literal quote.
                if index + 1 < len(line) and line[index + 1] == quote_char:
                    current += quote_char
                    index += 1
                else:
                    in_quotes = False
            else:
                in_quotes = True
        elif character == delimiter and not in_quotes:
            tokens.append(current)
            current = ""
        else:
            current += character
        index += 1

    tokens.append(current)  # Also preserves an empty field after a trailing delimiter.
    if in_quotes:
        raise ValueError("Log line contains an unclosed quoted field.")
    return tokens


def create_audit_filter(threshold):
    """Return a validation closure with an independent nonlocal audit counter."""
    audited_count = 0

    def validate(record):
        """Count each checked record and return whether its amount meets threshold."""
        nonlocal audited_count
        audited_count += 1
        try:
            return float(record["amount"]) >= threshold
        except (KeyError, TypeError, ValueError):
            return False

    def count():
        """Return how many records this filter has audited."""
        return audited_count

    # Expose the counter reader without using a global variable.
    validate.audit_count = count
    return validate


def make_positional_filters(criteria):
    """Create lambdas that test a chosen position without late-binding errors."""
    filters = []
    for k, expected in enumerate(criteria):
        # k=k and expected=expected bind the current values at creation time.
        filters.append(lambda row, k=k, expected=expected: len(row) > k and row[k] == expected)
    return filters


# ============================================================
# MODULE 3 — Data Inversion and In-Place Processing
# ============================================================

def build_reverse_index(raw_db):
    """Map each service tag to sorted unique (account ID, branch ID) pairs."""
    pairs_by_tag = {}
    for branch_id, account_records in raw_db.items():
        for account_id, service_tags in account_records:
            for tag in service_tags:
                if tag not in pairs_by_tag:
                    pairs_by_tag[tag] = set()
                pairs_by_tag[tag].add((account_id, branch_id))

    # One dictionary comprehension creates the final reverse-indexed view.
    return {tag: sorted(list(pairs)) for tag, pairs in pairs_by_tag.items()}


def clean_transaction_queue(data_list):
    """Clean a heterogeneous list in place and preserve its object identity."""
    for index in range(len(data_list)):
        item = data_list[index]

        if isinstance(item, tuple):
            data_list[index] = list(item)
            item = data_list[index]

        if isinstance(item, set):
            # Transaction IDs that are even are removed using set difference.
            evens = set()
            for value in item:
                if isinstance(value, int) and value % 2 == 0:
                    evens.add(value)
            data_list[index] = item - evens
        elif isinstance(item, list):
            # Sort each embedded list in descending order.
            try:
                item.sort(reverse=True)
            except TypeError:
                pass

    # Remove duplicate primitive values by scanning and deleting by index.
    index = 0
    while index < len(data_list):
        item = data_list[index]
        if isinstance(item, (str, int, float, bool, bytes)):
            earlier = False
            scan = 0
            while scan < index:
                previous = data_list[scan]
                if isinstance(previous, (str, int, float, bool, bytes)) and type(previous) is type(item) and previous == item:
                    earlier = True
                    break
                scan += 1
            if earlier:
                del data_list[index]
                continue
        index += 1
    return data_list


# ============================================================
# MODULE 4 — Transactional File Modifier and Error Logger
# ============================================================

class BaseSystemError(Exception):
    """Base exception for PTMAE-specific errors."""


class CorruptedRecordError(BaseSystemError):
    """Raised when a database record has an invalid structure or value."""


class OutOfBoundsError(BaseSystemError):
    """Raised when a requested value is outside allowed bounds."""


class InsufficientBalanceError(BaseSystemError):
    """Raised when an account cannot cover a requested transaction."""


def parse_account_record(line):
    """Validate and parse one account record in ID,TYPE,BALANCE format."""
    fields = parse_raw_log_line(line.rstrip("\n"))
    if len(fields) != 3:
        raise CorruptedRecordError("Expected three fields")
    account_id = fields[0].strip()
    account_type = fields[1].strip().upper()
    try:
        balance = float(fields[2].strip())
    except ValueError:
        raise CorruptedRecordError("Balance is not numeric")
    if not account_id or account_type not in ("SAVINGS", "CURRENT", "CREDIT"):
        raise CorruptedRecordError("Unknown account ID or type")
    if balance < 0:
        raise CorruptedRecordError("Balance cannot be negative")
    return account_id, account_type, balance


def _shift_file_tail(file_object, start_position, delta):
    """Shift bytes after start_position in a seekable binary file using chunks."""
    file_object.seek(0, 2)
    file_end = file_object.tell()
    if delta > 0:
        # Extend first, then copy backward to avoid overwriting unread data.
        file_object.seek(file_end + delta - 1)
        file_object.write(b"\0")
        position = file_end
        while position > start_position:
            chunk_start = position - 4096
            if chunk_start < start_position:
                chunk_start = start_position
            file_object.seek(chunk_start)
            chunk = file_object.read(position - chunk_start)
            file_object.seek(chunk_start + delta)
            file_object.write(chunk)
            position = chunk_start
    elif delta < 0:
        # Copy forward when moving data toward the beginning of the file.
        position = start_position
        while position < file_end:
            file_object.seek(position)
            chunk_size = 4096
            remaining = file_end - position
            if remaining < chunk_size:
                chunk_size = remaining
            chunk = file_object.read(chunk_size)
            if not chunk:
                break
            file_object.seek(position + delta)
            file_object.write(chunk)
            position += len(chunk)
        file_object.truncate(file_end + delta)


def update_account_in_place(account_id, new_type, new_balance, db_path="accounts.db"):
    """Update one record in place while preserving all neighbouring records."""
    if new_type not in ("SAVINGS", "CURRENT", "CREDIT"):
        raise OutOfBoundsError("Unknown account type")
    if not isinstance(new_balance, (int, float)) or new_balance < 0:
        raise OutOfBoundsError("Balance must be a non-negative number")

    # Binary r+b permits precise byte offsets and avoids text-mode seek ambiguity.
    processed = 0
    rejected = 0
    found = False
    try:
        with open(db_path, "r+b") as database:
            line_number = 0
            while True:
                record_start = database.tell()
                line = database.readline()
                if not line:
                    break
                line_number += 1
                processed += 1
                try:
                    decoded = line.decode("utf-8")
                    old_id, old_type, old_balance = parse_account_record(decoded)
                    if old_id == account_id:
                        found = True
                        replacement = "{},{},{:.2f}\n".format(account_id, new_type, new_balance).encode("utf-8")
                        # Preserve whether the original record had a final newline.
                        if not line.endswith(b"\n"):
                            replacement = replacement.rstrip(b"\n")
                        old_length = len(line)
                        new_length = len(replacement)
                        tail_start = record_start + old_length
                        _shift_file_tail(database, tail_start, new_length - old_length)
                        database.seek(record_start)
                        database.write(replacement)
                        database.flush()
                        break
                except (UnicodeDecodeError, CorruptedRecordError, ValueError) as error:
                    rejected += 1
                    with open("corrupted.log", "a", encoding="utf-8") as log:
                        log.write("Line {}: {} | {}\n".format(line_number, line.decode("utf-8", errors="replace").rstrip(), error))
                else:
                    # A validated record is recorded in the ledger.
                    with open("ledger.txt", "a", encoding="utf-8") as ledger:
                        ledger.write("{} | VALID | {}\n".format(datetime.now().isoformat(timespec="seconds"), decoded.rstrip()))
    except OSError as error:
        print("Database error:", error)
    finally:
        print("File processing complete. Processed: {}, rejected: {}".format(processed, rejected))

    if not found:
        raise CorruptedRecordError("Account ID was not found or database could not be updated")
    return True


def audit_database(db_path="accounts.db"):
    """Read all records, logging rejected rows and reporting totals."""
    processed = 0
    rejected = 0
    accepted = 0
    try:
        with open(db_path, "r", encoding="utf-8") as database:
            for line_number, line in enumerate(database, 1):
                processed += 1
                try:
                    record = parse_account_record(line)
                except (CorruptedRecordError, ValueError) as error:
                    rejected += 1
                    with open("corrupted.log", "a", encoding="utf-8") as log:
                        log.write("Line {}: {} | {}\n".format(line_number, line.rstrip(), error))
                else:
                    accepted += 1
                    with open("ledger.txt", "a", encoding="utf-8") as ledger:
                        ledger.write("{} | ACCEPTED | {}\n".format(datetime.now().isoformat(timespec="seconds"), line.rstrip()))
    except FileNotFoundError:
        print("accounts.db not found. Create it with one account record per line.")
    finally:
        print("Audit complete. Processed: {}, accepted: {}, rejected: {}".format(processed, accepted, rejected))
    return processed, accepted, rejected


# ============================================================
# MODULE 5 — Object-Oriented Architecture and Polymorphic Engine
# ============================================================

class Account:
    """Base account with private balance and protected account identifier."""
    total_accounts = 0

    def __init__(self, account_id, balance):
        """Create an account and validate the initial balance."""
        self._account_id = str(account_id)
        self.__balance = 0.0
        self.set_balance(balance)
        Account.total_accounts += 1

    def get_balance(self):
        """Return the account balance."""
        return self.__balance

    def set_balance(self, value):
        """Set a non-negative numeric balance."""
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise OutOfBoundsError("Balance must be numeric")
        if value < 0:
            raise OutOfBoundsError("Balance cannot be negative")
        self.__balance = float(value)

    def get_account_id(self):
        """Return the account identifier."""
        return self._account_id

    def set_account_id(self, value):
        """Set a non-empty account identifier."""
        if not isinstance(value, str) or not value:
            raise OutOfBoundsError("Account ID must be a non-empty string")
        self._account_id = value

    def _set_balance_for_credit_or_overdraft(self, value):
        """Internal helper for subclasses that support a negative balance."""
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise OutOfBoundsError("Balance must be numeric")
        self.__balance = float(value)

    def process_settlement(self, amount):
        """Base settlement method; subclasses implement account-specific rules."""
        raise NotImplementedError("Subclass must implement settlement")


class SavingsAccount(Account):
    """Savings account must retain a minimum balance of 1000."""
    def __init__(self, account_id, balance):
        """Initialize through super() without hardcoding the base class."""
        super().__init__(account_id, balance)

    def process_settlement(self, amount):
        """Deduct amount only if the minimum balance remains available."""
        _validate_amount(amount)
        remaining = self.get_balance() - amount
        if remaining < 1000:
            raise InsufficientBalanceError("Savings account must retain 1000")
        self.set_balance(remaining)
        return self.get_balance()


class CurrentAccount(Account):
    """Current account permits overdraft up to its private limit."""
    def __init__(self, account_id, balance, overdraft_limit=2000):
        """Initialize a current account with a private overdraft limit."""
        super().__init__(account_id, balance)
        if overdraft_limit < 0:
            raise OutOfBoundsError("Overdraft limit cannot be negative")
        self.__overdraft_limit = float(overdraft_limit)

    def process_settlement(self, amount):
        """Deduct amount if the resulting balance respects overdraft limit."""
        _validate_amount(amount)
        remaining = self.get_balance() - amount
        if remaining < -self.__overdraft_limit:
            raise InsufficientBalanceError("Overdraft limit exceeded")
        self._set_balance_for_credit_or_overdraft(remaining)
        return remaining


class CreditAccount(Account):
    """Credit account charges a 2.5 percent surcharge on each transaction."""
    def __init__(self, account_id, balance, credit_limit=10000):
        """Initialize credit account and its private limit."""
        super().__init__(account_id, balance)
        if credit_limit < 0:
            raise OutOfBoundsError("Credit limit cannot be negative")
        self.__credit_limit = float(credit_limit)

    def process_settlement(self, amount):
        """Add surcharge, then charge the total against available credit."""
        _validate_amount(amount)
        total = amount + amount * 2.5 / 100
        remaining = self.get_balance() - total
        if remaining < -self.__credit_limit:
            raise InsufficientBalanceError("Credit limit exceeded")
        if remaining >= 0:
            self.set_balance(remaining)
        else:
            self._set_balance_for_credit_or_overdraft(remaining)
        return remaining


def _validate_amount(amount):
    """Validate a transaction amount."""
    if not isinstance(amount, (int, float)) or isinstance(amount, bool):
        raise OutOfBoundsError("Transaction amount must be numeric")
    if amount < 0:
        raise OutOfBoundsError("Transaction amount cannot be negative")


def execute_batch_settlement(account_list, transaction_amount):
    """Settle each account independently and report successes and failures."""
    successes = []
    failures = []
    for account in account_list:
        try:
            new_balance = account.process_settlement(transaction_amount)
        except (BaseSystemError, NotImplementedError) as error:
            failures.append((account.get_account_id(), str(error)))
            print("FAILED {}: {}".format(account.get_account_id(), error))
        else:
            successes.append((account.get_account_id(), new_balance))
            print("SUCCESS {}: balance {:.2f}".format(account.get_account_id(), new_balance))
    print("Batch result: {} success(es), {} failure(s).".format(len(successes), len(failures)))
    return successes, failures


# ============================================================
# Demonstration code — exercises the major requirements
# ============================================================

def run_demonstrations():
    """Run demonstrations for Units 1-5 without requiring user input."""
    print("=" * 60)
    print("PTMAE DEMONSTRATIONS")
    print("=" * 60)

    # Unit 1: arithmetic and early trajectory stopping.
    print("\n[Unit 1] Interest:", round(compound_interest(1000, 5, 2), 2))
    print("[Unit 1] Penalty:", round(calculate_penalty(500, 2), 2))
    print("[Unit 1] Guard:", trajectory_guard(1200, [-100, -200, 50], 100))

    # Unit 2: manual parsing, closure state, and lambda binding.
    print("\n[Unit 2] Parsed log:", parse_raw_log_line('Acc1,"cash, transfer","said ""hello"""'))
    audit_filter = create_audit_filter(100)
    print("[Unit 2] Audit checks:", audit_filter({"amount": 150}), audit_filter({"amount": 40}))
    print("[Unit 2] Audit count:", audit_filter.audit_count())
    positional = make_positional_filters(["Acc1", "DEPOSIT"])
    print("[Unit 2] Lambda checks:", positional[0](["Acc1", "DEPOSIT"]), positional[1](["Acc1", "DEPOSIT"]))

    # Unit 3: reverse indexing and in-place queue processing.
    raw_db = {
        "BRANCH_01": [("Acc101", {"DEPOSIT", "UPI"}), ("Acc102", {"LOAN", "UPI"})],
        "BRANCH_02": [("Acc101", {"SAVINGS", "UPI"}), ("Acc103", {"CARD", "DEPOSIT"})],
    }
    print("\n[Unit 3] Reverse index:", build_reverse_index(raw_db))
    queue = [(3, 1), [2, 8, 4], {1, 2, 3, 4}, 7, 7, "TXN"]
    original_identity = id(queue)
    clean_transaction_queue(queue)
    print("[Unit 3] Clean queue:", queue, "| identity preserved:", id(queue) == original_identity)

    # Unit 4: custom exception hierarchy and database file audit.
    print("\n[Unit 4] Exception inheritance:", issubclass(CorruptedRecordError, BaseSystemError),
          issubclass(OutOfBoundsError, BaseSystemError),
          issubclass(InsufficientBalanceError, BaseSystemError))
    print("[Unit 4] To test file operations, create accounts.db then call audit_database().")

    # Unit 5: polymorphism, encapsulation, and batch fault isolation.
    print("\n[Unit 5] Private attribute via mangled name is available for demonstration:",
          hasattr(SavingsAccount("DEMO", 2000), "_Account__balance"))
    try:
        demo = SavingsAccount("S-DEMO", 2000)
        print(demo.__balance)  # Intentionally demonstrates name-mangling protection.
    except AttributeError:
        print("[Unit 5] obj.__balance raises AttributeError as expected.")
    accounts = [
        SavingsAccount("S101", 5000),
        CurrentAccount("C101", 500),
        CreditAccount("CR101", 1000),
        SavingsAccount("S102", 1200),  # This one may fail and must not stop the batch.
    ]
    execute_batch_settlement(accounts, 300)
    print("Total account objects created:", Account.total_accounts)


def main():
    """Run demonstrations and then offer the interactive command loop."""
    run_demonstrations()
    while True:
        answer = input("\nStart interactive command loop? (yes/no): ").strip().lower()
        if answer in ("yes", "y"):
            command_loop()
            break
        if answer in ("no", "n"):
            print("PTMAE demonstration finished.")
            break
        print("Please enter yes or no.")


if __name__ == "__main__":
    main()
